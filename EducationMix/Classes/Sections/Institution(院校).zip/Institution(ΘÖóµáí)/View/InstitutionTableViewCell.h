//
//  InstitutionTableViewCell.h
//  EducationMix
//
//  Created by Taosky on 2019/3/15.
//  Copyright © 2019 sam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InstitutionModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface InstitutionTableViewCell : UITableViewCell

@property (nonatomic, strong)InstitutionModel *model;

@end

NS_ASSUME_NONNULL_END
