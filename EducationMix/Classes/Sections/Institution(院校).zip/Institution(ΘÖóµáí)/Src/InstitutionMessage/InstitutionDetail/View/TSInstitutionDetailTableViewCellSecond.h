//
//  TSInstitutionDetailTableViewCellSecond.h
//  EducationMix
//
//  Created by Taosky on 2019/4/11.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TSInstitutionDetailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TSInstitutionDetailTableViewCellSecond : UITableViewCell

@property (nonatomic, strong)TSInstitutionDetailModel *model;


@end

NS_ASSUME_NONNULL_END
