//
//  TSTSInstitutionDetailAdvanceSubjectModel.h
//  EducationMix
//
//  Created by Taosky on 2019/3/27.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSTSInstitutionDetailAdvanceSubjectModel : NSObject

@property (nonatomic, strong)NSString *subject_name;
@property (nonatomic, strong)NSString *main_service_area;

@end

NS_ASSUME_NONNULL_END
