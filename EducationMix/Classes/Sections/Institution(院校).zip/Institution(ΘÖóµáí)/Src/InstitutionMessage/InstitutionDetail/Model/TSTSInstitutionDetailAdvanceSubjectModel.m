//
//  TSTSInstitutionDetailAdvanceSubjectModel.m
//  EducationMix
//
//  Created by Taosky on 2019/3/27.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import "TSTSInstitutionDetailAdvanceSubjectModel.h"

@implementation TSTSInstitutionDetailAdvanceSubjectModel

@end
