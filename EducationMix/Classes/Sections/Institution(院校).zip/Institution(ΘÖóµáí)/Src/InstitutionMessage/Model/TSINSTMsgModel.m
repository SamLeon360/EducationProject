//
//  TSINSTMsgModel.m
//  EducationMix
//
//  Created by Taosky on 2019/3/16.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import "TSINSTMsgModel.h"

@implementation TSINSTMsgModel

@end
