//
//  TSInstitutionMsgBoardViewModel.m
//  EducationMix
//
//  Created by Taosky on 2019/3/19.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import "TSInstitutionMsgBoardViewModel.h"

@implementation TSInstitutionMsgBoardViewModel

@end
