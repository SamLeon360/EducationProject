//
//  TSINSTMsgViewController.h
//  EducationMix
//
//  Created by Taosky on 2019/3/16.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface TSINSTMsgViewController : UIViewController

@property (nonatomic, assign)NSInteger academy_id;

@end

NS_ASSUME_NONNULL_END
