//
//  TSINSTMsgView.m
//  EducationMix
//
//  Created by Taosky on 2019/3/16.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import "TSINSTMsgView.h"

@implementation TSINSTMsgView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
