//
//  TSTeamDetailsMAdvanceSubjectodel.h
//  EducationMix
//
//  Created by Taosky on 2019/4/18.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSTeamDetailsMAdvanceSubjectodel : NSObject

@property(nonatomic, strong)NSString *subject_name;
@property(nonatomic, strong)NSString *technology_project;

@end

NS_ASSUME_NONNULL_END
