//
//  TSTeamDetailsViewController.h
//  EducationMix
//
//  Created by Taosky on 2019/4/9.
//  Copyright © 2019 iTaosky. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSTeamDetailsViewController : UIViewController
@property(nonatomic, assign)NSInteger team_id;

@end

NS_ASSUME_NONNULL_END
